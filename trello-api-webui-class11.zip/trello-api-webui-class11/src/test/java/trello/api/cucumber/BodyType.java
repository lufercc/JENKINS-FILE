package trello.api.cucumber;

public enum BodyType {
    RAW,
    MAP,
    OBJECT
}
