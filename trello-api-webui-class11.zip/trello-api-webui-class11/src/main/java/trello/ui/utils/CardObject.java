package trello.ui.utils;

public class CardObject {

    private String title;

    public CardObject(String title) {
        this.title = title;
    }

    public String getTitle() {
        return this.title;
    }

}
