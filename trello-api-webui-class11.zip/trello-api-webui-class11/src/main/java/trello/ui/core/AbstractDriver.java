package trello.ui.core;

import org.openqa.selenium.WebDriver;

public abstract class AbstractDriver {
    abstract WebDriver initDriver();
}
