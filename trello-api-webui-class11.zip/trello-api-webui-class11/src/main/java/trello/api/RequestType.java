package trello.api;

public enum RequestType {
    GET,
    POST,
    PUT,
    DELETE
}
